import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-vegetables',
  templateUrl: './vegetables.component.html',
  styleUrls: ['./vegetables.component.css']
})
export class VegetablesComponent implements OnInit {

  show: boolean = true;
  vegetableProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productYogurt = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Vegetable');
    this.vegetableProducts = productYogurt;

    if ( this.vegetableProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
