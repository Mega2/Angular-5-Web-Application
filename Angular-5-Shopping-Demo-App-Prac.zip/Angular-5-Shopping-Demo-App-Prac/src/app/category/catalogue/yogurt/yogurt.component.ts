import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-yogurt',
  templateUrl: './yogurt.component.html',
  styleUrls: ['./yogurt.component.css']
})
export class YogurtComponent implements OnInit {

  show: boolean = true;
  yogurtProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productYogurt = this.prod.getProductsInLocalStorage().filter(item => item.type === 'diary product');
    this.yogurtProducts = productYogurt;

    if ( this.yogurtProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
