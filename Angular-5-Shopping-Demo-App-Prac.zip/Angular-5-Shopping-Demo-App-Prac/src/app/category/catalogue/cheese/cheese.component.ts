import { Component, OnInit } from '@angular/core';
import { ProductService } from '../../../services/product.service';
import { DomSanitizer } from '@angular/platform-browser';
import { CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-cheese',
  templateUrl: './cheese.component.html',
  styleUrls: ['./cheese.component.css']
})
export class CheeseComponent implements OnInit {

  show: boolean = true;
  cheeseProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productCheese = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Cheese');
    this.cheeseProducts = productCheese;

    if ( this.cheeseProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
