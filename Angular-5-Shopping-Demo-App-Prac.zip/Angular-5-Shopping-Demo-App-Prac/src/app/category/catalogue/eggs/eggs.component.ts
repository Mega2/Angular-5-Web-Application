import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-eggs',
  templateUrl: './eggs.component.html',
  styleUrls: ['./eggs.component.css']
})
export class EggsComponent implements OnInit {

  eggProducts = []
  
  show: boolean = true;

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productEggs = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Milks');
    this.eggProducts = productEggs;

    if ( this.eggProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
