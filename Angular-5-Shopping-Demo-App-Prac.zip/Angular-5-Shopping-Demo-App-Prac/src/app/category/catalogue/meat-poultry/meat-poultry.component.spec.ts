import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MeatPoultryComponent } from './meat-poultry.component';

describe('MeatPoultryComponent', () => {
  let component: MeatPoultryComponent;
  let fixture: ComponentFixture<MeatPoultryComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MeatPoultryComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MeatPoultryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
