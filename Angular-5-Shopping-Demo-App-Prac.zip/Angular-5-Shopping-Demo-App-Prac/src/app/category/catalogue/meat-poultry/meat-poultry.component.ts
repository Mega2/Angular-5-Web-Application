import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-meat-poultry',
  templateUrl: './meat-poultry.component.html',
  styleUrls: ['./meat-poultry.component.css']
})
export class MeatPoultryComponent implements OnInit {

  show: boolean = true;
  meatPoultryProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productMeatPoultry = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Meat');
    this.meatPoultryProducts = productMeatPoultry;

    if ( this.meatPoultryProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
