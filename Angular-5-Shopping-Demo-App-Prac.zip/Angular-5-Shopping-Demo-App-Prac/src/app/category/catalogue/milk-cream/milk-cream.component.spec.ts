import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MilkCreamComponent } from './milk-cream.component';

describe('MilkCreamComponent', () => {
  let component: MilkCreamComponent;
  let fixture: ComponentFixture<MilkCreamComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MilkCreamComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MilkCreamComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
