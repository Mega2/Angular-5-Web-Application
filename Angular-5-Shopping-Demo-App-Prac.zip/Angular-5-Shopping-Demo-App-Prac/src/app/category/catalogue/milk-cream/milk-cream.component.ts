import { Component, OnInit } from '@angular/core';
import { ProductsComponent } from '../../../components/products/products.component';
import { ProductService } from '../../../services/product.service';

import { CartService } from '../../../services/cart.service';
import { CartItem } from '../../../model/cart-items';
import { Product } from '../../../model/product';


@Component({
  selector: 'app-milk-cream',
  templateUrl: './milk-cream.component.html',
  styleUrls: ['./milk-cream.component.css']
})
export class MilkCreamComponent implements OnInit {

  show: boolean = true;
  milkProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productMilk = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Milk');
    this.milkProducts = productMilk;

    if ( this.milkProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
