import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ButterMargarineComponent } from './butter-margarine.component';

describe('ButterMargarineComponent', () => {
  let component: ButterMargarineComponent;
  let fixture: ComponentFixture<ButterMargarineComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ButterMargarineComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ButterMargarineComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
