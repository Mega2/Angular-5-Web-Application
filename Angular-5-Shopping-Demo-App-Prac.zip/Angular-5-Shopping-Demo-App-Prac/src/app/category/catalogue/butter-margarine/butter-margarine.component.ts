import { Component, OnInit } from '@angular/core';
import { Product } from '../../../model/product';
import { ProductService, CartService } from '../../../services';

@Component({
  selector: 'app-butter-margarine',
  templateUrl: './butter-margarine.component.html',
  styleUrls: ['./butter-margarine.component.css']
})
export class ButterMargarineComponent implements OnInit {

  show: boolean = true;
  butterMargarineProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productButterMargarine = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Butter Margarine');
    this.butterMargarineProducts = productButterMargarine;

    if ( this.butterMargarineProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}

