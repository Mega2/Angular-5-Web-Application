import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SaladsHerbsComponent } from './salads-herbs.component';

describe('SaladsHerbsComponent', () => {
  let component: SaladsHerbsComponent;
  let fixture: ComponentFixture<SaladsHerbsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SaladsHerbsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SaladsHerbsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
