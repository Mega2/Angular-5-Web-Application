import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-salads-herbs',
  templateUrl: './salads-herbs.component.html',
  styleUrls: ['./salads-herbs.component.css']
})
export class SaladsHerbsComponent implements OnInit {

  show: boolean = true;
  saladHerbProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productSaladHerb = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Salads Fresh Herbs');
    this.saladHerbProducts = productSaladHerb;

    if ( this.saladHerbProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
