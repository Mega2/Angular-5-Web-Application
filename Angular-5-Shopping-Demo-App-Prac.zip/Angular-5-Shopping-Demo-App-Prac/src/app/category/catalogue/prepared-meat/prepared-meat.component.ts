import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-prepared-meat',
  templateUrl: './prepared-meat.component.html',
  styleUrls: ['./prepared-meat.component.css']
})
export class PreparedMeatComponent implements OnInit {

  show: boolean = true;
  prepeareMeatProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productPrepearedMeat = this.prod.getProductsInLocalStorage().filter(item => item.type === 'Prepeared Meat');
    this.prepeareMeatProducts = productPrepearedMeat;

    if ( this.prepeareMeatProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
