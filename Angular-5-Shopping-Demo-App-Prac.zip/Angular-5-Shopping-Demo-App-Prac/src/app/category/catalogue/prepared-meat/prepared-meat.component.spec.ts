import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreparedMeatComponent } from './prepared-meat.component';

describe('PreparedMeatComponent', () => {
  let component: PreparedMeatComponent;
  let fixture: ComponentFixture<PreparedMeatComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreparedMeatComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreparedMeatComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
