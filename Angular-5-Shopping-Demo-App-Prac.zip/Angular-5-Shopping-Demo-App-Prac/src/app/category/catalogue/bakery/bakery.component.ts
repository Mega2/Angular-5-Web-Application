import { Component, OnInit } from '@angular/core';
import { ProductService, CartService } from '../../../services';
import { Product } from '../../../model/product';

@Component({
  selector: 'app-bakery',
  templateUrl: './bakery.component.html',
  styleUrls: ['./bakery.component.css']
})
export class BakeryComponent implements OnInit {

  show: boolean = true;
  bakeryProducts = []

  constructor( private prod: ProductService, private cartService: CartService) { }
  
  ngOnInit() {
    
    var productBakery = this.prod.getProductsInLocalStorage().filter(item => item.type === 'bakery');
    this.bakeryProducts = productBakery;

    if ( this.bakeryProducts.length === 0  )
      this.show = false;
    
  }

  addItem( myProduct: Product ){
    this.cartService.addItemToCart(myProduct);
  }

}
