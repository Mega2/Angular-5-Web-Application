import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-fresh-food',
  templateUrl: './fresh-food.component.html',
  styleUrls: ['./fresh-food.component.css']
})
export class FreshFoodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
