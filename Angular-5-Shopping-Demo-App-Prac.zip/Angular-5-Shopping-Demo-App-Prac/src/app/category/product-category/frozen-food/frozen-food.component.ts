import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-frozen-food',
  templateUrl: './frozen-food.component.html',
  styleUrls: ['./frozen-food.component.css']
})
export class FrozenFoodComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
