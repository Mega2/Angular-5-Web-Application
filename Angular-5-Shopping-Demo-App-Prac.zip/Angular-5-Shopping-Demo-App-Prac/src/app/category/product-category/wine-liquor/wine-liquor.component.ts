import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-wine-liquor',
  templateUrl: './wine-liquor.component.html',
  styleUrls: ['./wine-liquor.component.css']
})
export class WineLiquorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
