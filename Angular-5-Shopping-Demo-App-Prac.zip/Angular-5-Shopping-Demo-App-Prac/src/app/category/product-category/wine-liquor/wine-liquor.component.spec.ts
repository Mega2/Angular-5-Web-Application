import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { WineLiquorComponent } from './wine-liquor.component';

describe('WineLiquorComponent', () => {
  let component: WineLiquorComponent;
  let fixture: ComponentFixture<WineLiquorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ WineLiquorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(WineLiquorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
