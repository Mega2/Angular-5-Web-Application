import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-food-cupboard',
  templateUrl: './food-cupboard.component.html',
  styleUrls: ['./food-cupboard.component.css']
})
export class FoodCupboardComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
