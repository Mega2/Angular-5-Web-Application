import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ElectronicOfficeComponent } from './electronic-office.component';

describe('ElectronicOfficeComponent', () => {
  let component: ElectronicOfficeComponent;
  let fixture: ComponentFixture<ElectronicOfficeComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ElectronicOfficeComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ElectronicOfficeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
