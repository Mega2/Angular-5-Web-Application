import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-electronic-office',
  templateUrl: './electronic-office.component.html',
  styleUrls: ['./electronic-office.component.css']
})
export class ElectronicOfficeComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
