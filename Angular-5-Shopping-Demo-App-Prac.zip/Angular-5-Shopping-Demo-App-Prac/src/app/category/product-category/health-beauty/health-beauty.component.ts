import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-health-beauty',
  templateUrl: './health-beauty.component.html',
  styleUrls: ['./health-beauty.component.css']
})
export class HealthBeautyComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
