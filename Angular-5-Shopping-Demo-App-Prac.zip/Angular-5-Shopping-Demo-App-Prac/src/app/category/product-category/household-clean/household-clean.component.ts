import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-household-clean',
  templateUrl: './household-clean.component.html',
  styleUrls: ['./household-clean.component.css']
})
export class HouseholdCleanComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
