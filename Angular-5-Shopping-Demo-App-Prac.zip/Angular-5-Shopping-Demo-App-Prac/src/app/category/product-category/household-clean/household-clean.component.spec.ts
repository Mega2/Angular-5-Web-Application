import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HouseholdCleanComponent } from './household-clean.component';

describe('HouseholdCleanComponent', () => {
  let component: HouseholdCleanComponent;
  let fixture: ComponentFixture<HouseholdCleanComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HouseholdCleanComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HouseholdCleanComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
