import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home-outdoor',
  templateUrl: './home-outdoor.component.html',
  styleUrls: ['./home-outdoor.component.css']
})
export class HomeOutdoorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
