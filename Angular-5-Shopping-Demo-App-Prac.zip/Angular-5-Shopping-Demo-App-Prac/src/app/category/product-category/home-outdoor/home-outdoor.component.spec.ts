import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeOutdoorComponent } from './home-outdoor.component';

describe('HomeOutdoorComponent', () => {
  let component: HomeOutdoorComponent;
  let fixture: ComponentFixture<HomeOutdoorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ HomeOutdoorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(HomeOutdoorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
