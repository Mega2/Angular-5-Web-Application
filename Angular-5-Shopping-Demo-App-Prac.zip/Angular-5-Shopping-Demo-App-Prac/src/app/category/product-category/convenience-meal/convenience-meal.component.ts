import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-convenience-meal',
  templateUrl: './convenience-meal.component.html',
  styleUrls: ['./convenience-meal.component.css']
})
export class ConvenienceMealComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
