import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ConvenienceMealComponent } from './convenience-meal.component';

describe('ConvenienceMealComponent', () => {
  let component: ConvenienceMealComponent;
  let fixture: ComponentFixture<ConvenienceMealComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ConvenienceMealComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ConvenienceMealComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
