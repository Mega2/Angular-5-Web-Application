import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import { error } from 'util';
import { Router } from '@angular/router';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class CustomerOrderService {

  constructor( private http: HttpClient, private router: Router ) { }

  customerOrder(bankName: string, bankAccount:any, userEmail: string, cart:any[], totalQuantity, totalCost, 
                                    orderedDate, deliveryDate, phoneNumber, address, closeShop, phone, sms){

    let bankingDetails = {
      "bankName": bankName,
      "accountNumber": bankAccount
    }

    let customerOrderDetails = {
      "cusEmail": userEmail,
      "orderedItems": cart,
      "totalQuantity": totalQuantity,
      "totalCost": totalCost,
      "orderDate": orderedDate,
      "deliveryDate": deliveryDate,
      "phoneNumber":phoneNumber,
      "address": address,
      "closeShop": closeShop,
      "contact": ("By email:" + phone + ":" + sms + ":"),
      "status": "ordered"
    }

    this.http.post<any>("/bank/validation/service/bank/validations", bankingDetails, httpOptions ).subscribe(
      response => {
        if(response.status === 'success'){
          
          this.http.post<any>('/order/service/save/order', customerOrderDetails, httpOptions).subscribe(
            response => {
              
              if ( response === null ){
                this.router.navigate(["/order-placed"]);
              }
              else{
                alert('Something is Wrong\nPlease Try Again...');
              }
            });

         }
         else {
           alert('There Is Something Wrong\nPlease Try Again...');
          }
        },
        error => {
          console.error("HTTP FAILURE ERROR!!!");
        });
      }
}

