import { Injectable } from '@angular/core';
import { Product } from '../model/product';
import { CartItem } from '../model/cart-items';
import { ThrowStmt } from '@angular/compiler';
import { ProductService } from '.';

@Injectable()
export class CartService {

  [x: string]: any;
  cart: Product[] = [];
  count:number = 1;

  constructor() {
   }

  addItemToCart( myProduct: Product ){

    let myCartItem: CartItem
    myCartItem = new CartItem()

    if ( this.checkExistenceOfProd(myProduct) === false ){
    
      myCartItem.name = myProduct.name
      myCartItem.manufacture = myProduct.manufacture
      myCartItem.price = myProduct.price
      myCartItem.image = myProduct.image
      myCartItem.count = this.count
      this.cart.push(myCartItem);
      
    }
    this.saveCart();
  }
  
  checkExistenceOfProd( prod: Product ) {
    
    this.cart = this.loadCart();
    for ( var i = 0; i < this.cart.length; i++){
        if (this.cart[i].manufacture === prod.manufacture) {
            return this.cart[i];
        }
    }
    return false;
  }

  addOneItem( prod: Product ) {
    
    this.cart = this.loadCart();
    for ( var i = 0; i < this.cart.length; i++){
        if (this.cart[i].manufacture === prod.manufacture) {
          this.cart[i].count += 1;        
          this.saveCart();		// before we return, save the cart
          return;		// similar to break
        }
       
    }
    this.saveCart();
  }

  removeItemFromCart( prod: Product ) {
    
    this.cart = this.loadCart();
    for ( var i = 0; i < this.cart.length; i++){
        if (this.cart[i].manufacture === prod.manufacture) {
            this.cart[i].count--;

            // if count = 0 -- remove item form cart
            if (this.cart[i].count === 0) {
              this.cart.splice(i, 1);	// remove that item from cart
            }
            break;
        }
    }
    this.saveCart();
  }

  removeItemFromCartAll( prod: Product ) {
    
    this.cart = this.loadCart();
    for ( var i = 0; i < this.cart.length; i++){
        if (this.cart[i].manufacture === prod.manufacture) {
            this.cart.splice(i, 1);
            break;
        }
    }
    this.saveCart();
  }

  emptyCart() {
    this.cart = this.loadCart();
    this.cart = [];
    this.saveCart();
  }

  totalCart() {
    var total = 0;
    this.cart = this.loadCart();
    for ( var i = 0; i < this.cart.length; i++){
        total += this.cart[i].price * this.cart[i].count;
        //sessionStorage.setItem('total-cost', JSON.stringify( total.toFixed(2) ));
    } 
    return total.toFixed(2);
  }

  getTotalQuantity(){
    var toatalQuantity = 0;
    this.cart = this.loadCart();

    for ( var i = 0; i < this.cart.length; i++){
      toatalQuantity += this.cart[i].count;
    }
    return toatalQuantity;
  }

  getTotal(){
    return JSON.parse(sessionStorage.getItem('total-cost') );
  }

  saveCart(){
    localStorage.setItem('cart-items', JSON.stringify( this.cart));
  }

  loadCart():Array<Product>{

    this.products = JSON.parse(localStorage.getItem('cart-items') )

    if ( this.products === null ){
      this.products = [];
    }
    else{
      this.products = JSON.parse(localStorage.getItem('cart-items') );
    }

    return this.products;
  }

}
