import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import { error } from 'util';
import { Router } from '@angular/router';
 
const httpOptions = {
    headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class UserServiceService {

  constructor( private http: HttpClient, private router: Router ) { }

  login( email: string, password: string ){
    
    let body = { "email": email, "password": password};

    this.http.post<any>('/customer/service/logging', body, httpOptions).subscribe(
      response => {
        if(response.status === 'success'){
            alert(response.message);
            
            sessionStorage.setItem('user', JSON.stringify(email));

            this.router.navigate(["/"]);

         }else {
         alert('Login Unsuccessful\nPlease Try Again...');
        }
      },
      error => {
        console.error("HTTP FAILURE ERROR!!!");
      }
    );
    
  }

  signup( name: string, lastname: string, email: string, password: string ){
    
    let body = { "name": name, "surname": lastname, "email": email, "password": password};

    this.http.post<any>('/customer/service/register', body, httpOptions).subscribe(
      response => {
        if(response.status === 'success'){
            alert(response.message);
            
            sessionStorage.setItem('user', JSON.stringify(email));

            this.router.navigate(["/"]);

         }else {
           alert('Registration Failure\nPlease Try Again...');
        }
      },
      error => {
        console.error("HTTP FAILURE ERROR!!!");
      }
    );
  }

  loggingOut(){
    if (confirm("Are Your Sure You Want Log Out") === true) {
      sessionStorage.clear();
    } else {
      alert("You Are Still With Us");
    }
  }
}
