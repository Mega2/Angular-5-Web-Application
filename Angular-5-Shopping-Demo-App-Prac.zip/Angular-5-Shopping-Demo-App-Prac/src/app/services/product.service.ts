import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs/Rx';
import { error } from 'util';

import { Product } from '../model/product'
import { DomSanitizer } from '@angular/platform-browser';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};

@Injectable()
export class ProductService {
  
  allProducts = [];
  products: Array<Product> = [];

  constructor( private http: HttpClient ) {}

  getAllProducts(){
    this.http.get<any>('/product/service/send/all/products').subscribe (
        data => {
          
          this.allProducts = data;

          this.allProducts.forEach(function(item) {
            if (item.image) {
              var edittedImageString = item.image.substring(item.image.indexOf(",") + 1 );
              item.image = "data:image/jpeg;base64," + edittedImageString;
            }
          });
          
          sessionStorage.setItem('product-data', JSON.stringify( this.allProducts ));
        },
        error => {
            console.error("HTTP FAILURE ERROR!!!");
        }
    );
  }

  getProductsInLocalStorage():Array<Product>{
    return this.products = JSON.parse(sessionStorage.getItem('product-data') );
  }
}