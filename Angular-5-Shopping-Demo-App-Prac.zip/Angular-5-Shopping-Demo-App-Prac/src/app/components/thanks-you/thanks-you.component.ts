import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-thanks-you',
  templateUrl: './thanks-you.component.html',
  styleUrls: ['./thanks-you.component.css']
})
export class ThanksYouComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
