import { Component, OnInit } from '@angular/core';
import { UserServiceService, CartService } from '../../services';
import { FormGroup, FormControl } from '@angular/forms';
import { CustomerOrderService } from '../../services/customer-order.service';
@Component({
  selector: 'app-check-out',
  templateUrl: './check-out.component.html',
  styleUrls: ['./check-out.component.css']
})
export class CheckOutComponent implements OnInit {

  phoneNumber: number;
  phone: string;
  sms: string;
  address: string;
  closeShop: string;
  deliverDate: any;
  accountNumber: any;
  bankName: string;

  bankNames = [
    {name: "Absa"}, {name: "Standard Bank"}, {name: "Nedbank"}, {name: "FNB"}, {name: "Capitec"}, {name: "Investec"}
  ];

  confirmOrderForm;

  constructor( private userService: UserServiceService, private cartService:CartService, private cusOrderService: CustomerOrderService ) {}

  ngOnInit() {

    if ( this.cartService.loadCart().length === null ){
    this.cartService.loadCart().length === null;
    }
    else{
      this.cartService.loadCart().length
    }

    this.cartService.totalCart();
    
    this.confirmOrderForm = new FormGroup ({
      phoneNumber: new FormControl(),
      phone: new FormControl(),
      sms: new FormControl(),
      address: new FormControl(),
      closeShop: new FormControl(),
      deliverDate: new FormControl(),
      accountNumber: new FormControl(),
      bankName: new FormControl()
    })
  }

  logOut(){
    this.userService.loggingOut();
  }

  confirmOrder = function(confirmOrder: orderInterface){

    var date = new Date();
    var dd = date.getDate();
    var mm = date.getMonth() + 1; //January is 0!
    var yyyy = date.getFullYear();
    var orderedDate = yyyy + '-' + dd + '-' + mm;

    this.address = confirmOrder.address;
    this.closeShop = confirmOrder.closeShop;
    this.deliveryDate = confirmOrder.deliverDate;
    this.phone = confirmOrder.phone;
    this.phoneNumber = confirmOrder.phoneNumber;
    this.sms = confirmOrder.sms;
    this.bankName = confirmOrder.bankName;
    this.accountNumber = confirmOrder.accountNumber;

    var userEmail = JSON.parse(sessionStorage.getItem('user') );
    var cartItems = this.cartService.loadCart();
    var totalQuantity = this.cartService.getTotalQuantity();
    var totalCost = this.cartService.totalCart();

    if (this.phone === true ) 
      this.phone = " and phone call";
    else
      this.phone = "";

    if ( this.sms === true ) 
      this.sms = " and SMS";
    else
      this.sms = "";
      
    this.cusOrderService.customerOrder(this.bankName, this.accountNumber, userEmail, cartItems,  totalQuantity, totalCost, 
      orderedDate, this.deliveryDate, this.phoneNumber, this.address, this.closeShop, this.phone, this.sms);
    }
}



interface orderInterface{
  phoneNumber: number;
  phone: string;
  sms: string;
  address: string;
  closeShop: string;
  deliverDate: any;
  accountNumber: any;
  bankName: string;
}