import { Component, OnInit } from '@angular/core';
import {  UserServiceService } from '../../services/index';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  userEmail: string;
  userPassword: string;
  userName: string;
  userLastname: string;

  constructor( private userServiceService: UserServiceService ) { }

  ngOnInit() {
  }

  register(){
    this.userServiceService.signup ( this.userName, this.userLastname, this.userEmail, this.userPassword );
  }

}
