import { Component, OnInit } from '@angular/core';
import { CartService, UserServiceService } from '../../services';
import { Product } from '../../model/product';
import { COMPOSITION_BUFFER_MODE } from '@angular/forms';

@Component({
  selector: 'app-shopping-cart',
  templateUrl: './shopping-cart.component.html',
  styleUrls: ['./shopping-cart.component.css']
})
export class ShoppingCartComponent implements OnInit {

  constructor( private cartService: CartService, private userService:UserServiceService ) { }

  ngOnInit() {

    this.cartService.loadCart().length;
    this.cartService.loadCart();
    this.cartService.totalCart();

  }

  addQuantity( myProduct: Product ){
    this.cartService.addOneItem( myProduct );    
  }

  removeQuantity( myProduct: Product ){
    this.cartService.removeItemFromCart( myProduct );    
  }

  removeProduct( myProduct: Product ){
    this.cartService.removeItemFromCartAll( myProduct );
  }

  clearCart(){
    this.cartService.emptyCart();
  }

  logOut(){
    this.userService.loggingOut();
  }

}
