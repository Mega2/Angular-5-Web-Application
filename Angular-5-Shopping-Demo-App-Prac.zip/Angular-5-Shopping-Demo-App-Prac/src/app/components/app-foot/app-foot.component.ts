import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-foot',
  templateUrl: './app-foot.component.html',
  styleUrls: ['./app-foot.component.css']
})
export class AppFootComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
