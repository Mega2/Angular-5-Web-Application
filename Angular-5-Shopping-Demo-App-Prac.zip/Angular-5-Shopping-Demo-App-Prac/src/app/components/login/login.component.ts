import { Component, OnInit } from '@angular/core';
import {  UserServiceService } from '../../services/index';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  userEmail: string;
  userPassword: string;

  constructor( private userServiceService: UserServiceService ) { }

  ngOnInit() {}

  logMe(){

    console.log (this.userEmail);

    if ( (this.userEmail === "undefined" || this.userPassword === "undefined") || 
    (this.userEmail === "undefined" && this.userPassword === "undefined") ){
      alert("Please Fill In The Empty Fields");
    }
    else {
      this.userServiceService.login( this.userEmail, this.userPassword );
    }

  }
}
