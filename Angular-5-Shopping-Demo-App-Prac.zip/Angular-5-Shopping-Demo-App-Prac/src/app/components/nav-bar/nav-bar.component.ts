import { Component, OnInit } from '@angular/core';
import { UserServiceService, CartService } from '../../services/index';

@Component({
  selector: 'app-nav-bar',
  templateUrl: './nav-bar.component.html',
  styleUrls: ['./nav-bar.component.css']
})
export class NavBarComponent implements OnInit {

  productSearch: string;
  cartLength: number;
  
  constructor( private userService: UserServiceService, private cartService: CartService ) { }

  ngOnInit() {
    this.cartService.loadCart().length;
  }

  logOut(){
    this.userService.loggingOut();
  }

  searchProduct(){
    alert("to be implemented -- search");
  }

}
