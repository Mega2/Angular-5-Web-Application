import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { Routes, RouterModule } from '@angular/router';

import { appChildrenRouting } from './app-child-routes';

import { AppComponent } from './app.component';
import { HomeComponent } from './components/home/home.component';
import { AboutUsComponent } from './components/about-us/about-us.component';
import { LoginComponent } from './components/login/login.component';
import { ProductsComponent } from './components/products/products.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { FoodCupboardComponent } from './category/product-category/food-cupboard/food-cupboard.component';
import { FrozenFoodComponent } from './category/product-category/frozen-food/frozen-food.component';
import { WineLiquorComponent } from './category/product-category/wine-liquor/wine-liquor.component';
import { BeverageComponent } from './category/product-category/beverage/beverage.component';
import { HealthBeautyComponent } from './category/product-category/health-beauty/health-beauty.component';
import { BabyComponent } from './category/product-category/baby/baby.component';
import { HouseholdCleanComponent } from './category/product-category/household-clean/household-clean.component';
import { HomeOutdoorComponent } from './category/product-category/home-outdoor/home-outdoor.component';
import { ConvenienceMealComponent } from './category/product-category/convenience-meal/convenience-meal.component';
import { ElectronicOfficeComponent } from './category/product-category/electronic-office/electronic-office.component';
import { PetsComponent } from './category/product-category/pets/pets.component';

import { FreshFoodComponent } from './category/product-category/fresh-food/fresh-food.component';
import { MilkCreamComponent } from './category/catalogue/milk-cream/milk-cream.component';
import { CheeseComponent } from './category/catalogue/cheese/cheese.component';


import {  UserServiceService, ProductService, CartService, CustomerOrderService } from './services/index';
import { NavBarComponent } from './components/nav-bar/nav-bar.component';
import { ShoppingCartComponent } from './components/shopping-cart/shopping-cart.component';
import { CheckOutComponent } from './components/check-out/check-out.component';
import { AppFootComponent } from './components/app-foot/app-foot.component';
import { ThanksYouComponent } from './components/thanks-you/thanks-you.component';
import { YogurtComponent } from './category/catalogue/yogurt/yogurt.component';
import { EggsComponent } from './category/catalogue/eggs/eggs.component';
import { ButterMargarineComponent } from './category/catalogue/butter-margarine/butter-margarine.component';
import { BakeryComponent } from './category/catalogue/bakery/bakery.component';
import { FruitComponent } from './category/catalogue/fruit/fruit.component';
import { VegetablesComponent } from './category/catalogue/vegetables/vegetables.component';
import { SaladsHerbsComponent } from './category/catalogue/salads-herbs/salads-herbs.component';
import { PreparedMeatComponent } from './category/catalogue/prepared-meat/prepared-meat.component';
import { MeatPoultryComponent } from './category/catalogue/meat-poultry/meat-poultry.component';


  const appRoutes: Routes = [
  { path: 'home', component: HomeComponent },

  { path: 'login', component: LoginComponent },
  { path: 'register', component: SignUpComponent },
  { path: 'about', component: AboutUsComponent },
  { path: 'products', component: ProductsComponent},
  { path: 'cupboard-food', component: FoodCupboardComponent },
  { path: 'frozen-food', component: FrozenFoodComponent },
  { path: 'wine-liquor-food', component: WineLiquorComponent },
  { path: 'baverage', component: BeverageComponent },
  { path: 'health_beauty', component: HealthBeautyComponent },
  { path: 'baby', component: BabyComponent },
  { path: 'house-cleaning', component: HouseholdCleanComponent},
  { path: 'home-outdoor', component: HomeOutdoorComponent },
  { path: 'convience-meal', component: ConvenienceMealComponent },
  { path: 'electronic_office', component: ElectronicOfficeComponent },
  { path: 'health_beauty', component: HealthBeautyComponent },
  { path: 'pets', component: PetsComponent },
  { path: 'fresh-food', component: FreshFoodComponent },
  { path: 'milks-creams', component: MilkCreamComponent},

  { path: 'cheeses', component: CheeseComponent},
  { path: 'yogurts', component: YogurtComponent},
  { path: 'eggs', component: EggsComponent},
  { path: 'butters-margarins', component: ButterMargarineComponent},
  { path: 'bakery', component: BakeryComponent},
  { path: 'fruits', component: FruitComponent},
  { path: 'vegetables', component: VegetablesComponent},
  { path: 'salads-fresh-herbs', component: SaladsHerbsComponent},
  { path: 'prepared-meat', component: PreparedMeatComponent},
  { path: 'meat-poultry', component: MeatPoultryComponent},


  
  { path: 'shopping-cart', component: ShoppingCartComponent },
  { path: 'check-out', component: CheckOutComponent },

  { path: 'order-placed', component: ThanksYouComponent },


  { path: '', redirectTo: '/home', pathMatch: 'full' },    // whenever path is empty --> redirect
  { path: '**', redirectTo: '/home', pathMatch: 'full' }   // if path is anything not defined --> redirect
  
  
]

@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutUsComponent,
    LoginComponent,
    ProductsComponent,
    SignUpComponent,
    FoodCupboardComponent,
    FrozenFoodComponent,
    WineLiquorComponent,
    BeverageComponent,
    HealthBeautyComponent,
    BabyComponent,
    HouseholdCleanComponent,
    HomeOutdoorComponent,
    ConvenienceMealComponent,
    ElectronicOfficeComponent,
    PetsComponent,
    FreshFoodComponent,
    MilkCreamComponent,
    CheeseComponent,
    NavBarComponent,
    ShoppingCartComponent,
    CheckOutComponent,
    AppFootComponent,
    ThanksYouComponent,
    YogurtComponent,
    EggsComponent,
    ButterMargarineComponent,
    FruitComponent,
    VegetablesComponent,
    SaladsHerbsComponent,
    PreparedMeatComponent,
    MeatPoultryComponent,
    BakeryComponent
  ],
  imports: [
    BrowserModule,
    RouterModule.forRoot(appRoutes),
    FormsModule,
    HttpClientModule,
    ReactiveFormsModule
  ],
  exports: [
    RouterModule
  ],
  providers: [ 
    UserServiceService, 
    ProductService,
    CartService,
    CustomerOrderService
  ],
  bootstrap: [ AppComponent ]
})
export class AppModule { }
