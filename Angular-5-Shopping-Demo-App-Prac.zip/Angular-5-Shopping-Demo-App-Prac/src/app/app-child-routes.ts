
import { NgModule }             from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { FreshFoodComponent } from './category/product-category/fresh-food/fresh-food.component';
import { MilkCreamComponent } from './category/catalogue/milk-cream/milk-cream.component';
import { CheeseComponent } from './category/catalogue/cheese/cheese.component';


import { ModuleWithProviders } from '@angular/core';

const appChildRoutes: Routes = [{

 path: 'fresh-food', 
 component: FreshFoodComponent, 
    children: [
      {
          path: 'milks-creams', 
          component: MilkCreamComponent
        },
        {
            path: 'cheeses', 
            component: CheeseComponent
        }
    ] 
}]

export const appChildrenRouting: ModuleWithProviders = RouterModule.forRoot(appChildRoutes);